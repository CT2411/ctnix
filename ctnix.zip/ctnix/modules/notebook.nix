{
  pkgs,
  inputs,
  ...
}:
{
  imports = [
    ./nixos/claude-code.nix
    ./nixos/disk.nix
    ./nixos/hardware-dev.nix
    ./nixos/lockscreen.nix
    ./nixos/niri.nix
    ./nixos/printing.nix
    ./nixos/virtualisation.nix
    ./ct.nix
  ];

  networking = {
    hostName = "notebook";
    networkmanager.enable = true;
    modemmanager.enable = false;
  };

  services = {
    power-profiles-daemon.enable = true;
    thermald.enable = true;

    logind.settings.Login = {
      HandleLidSwitch = "suspend-then-hibernate";
      HandleLidSwitchExternalPower = "lock";
      HandleLidSwitchDocked = "ignore";
    };

    pipewire = {
      enable = true;
      pulse.enable = true;
      alsa.enable = true;
    };

    upower = {
      enable = true;
      usePercentageForPolicy = true;
      percentageLow = 20;
      percentageCritical = 10;
      percentageAction = 5;
      criticalPowerAction = "Hibernate";
    };

    fwupd.enable = true;

    speechd.enable = false;

    getty = {
      autologinUser = "ct";
      autologinOnce = true;
    };

    xserver.xkb = {
      layout = "de";
      options = "caps:escape";
    };
  };

  hardware = {
    enableRedistributableFirmware = true;
    cpu.intel.updateMicrocode = true;

    graphics.extraPackages = [ pkgs.intel-media-driver ];

    bluetooth.enable = true;
  };

  programs = {
    nh = {
      enable = true;
      flake = "/home/ct/ctnix";
      clean = {
        enable = true;
        dates = "weekly";
        extraArgs = "--keep 5 --optimise";
      };
    };
    solaar.enable = true;
    nano.enable = false;
  };

  environment.defaultPackages = [ ];

  security.rtkit.enable = true;

  systemd.sleep.settings.Sleep.HibernateDelaySec = "2h";

  boot = {
    supportedFilesystems = [ "ntfs" ];

    initrd.availableKernelModules = [
      "nvme"
      "thunderbolt"
      "xhci_pci"
      "usbhid"
    ];

    kernelModules = [ "kvm-intel" ];
    tmp.cleanOnBoot = true;

    loader = {
      systemd-boot = {
        enable = true;
        configurationLimit = 5;
        editor = false;
      };
      efi.canTouchEfiVariables = true;
      timeout = 0;
    };

    kernel.sysctl = {
      "vm.page-cluster" = 0;
      "vm.swappiness" = 180;
    };
  };

  time.timeZone = "Europe/Berlin";

  i18n = {
    defaultLocale = "en_US.UTF-8";
    extraLocaleSettings = {
      LC_ADDRESS = "de_DE.UTF-8";
      LC_IDENTIFICATION = "de_DE.UTF-8";
      LC_MEASUREMENT = "de_DE.UTF-8";
      LC_MONETARY = "de_DE.UTF-8";
      LC_NAME = "de_DE.UTF-8";
      LC_NUMERIC = "de_DE.UTF-8";
      LC_PAPER = "de_DE.UTF-8";
      LC_TELEPHONE = "de_DE.UTF-8";
      LC_TIME = "de_DE.UTF-8";
    };
  };

  console.keyMap = "de-latin1";

  documentation = {
    doc.enable = false;
    info.enable = false;
    nixos.enable = false;
  };

  home-manager = {
    useGlobalPkgs = true;
    useUserPackages = true;
    backupFileExtension = "bak";
    overwriteBackup = true;
    extraSpecialArgs = { inherit inputs; };
  };

  nix = {
    channel.enable = false;
    settings = {
      download-buffer-size = 134217728;
      warn-dirty = false;
      experimental-features = [
        "nix-command"
        "flakes"
      ];
    };
  };

  users.mutableUsers = false;

  zramSwap.enable = true;

  fonts.packages = [
    pkgs.nerd-fonts.jetbrains-mono
    pkgs.noto-fonts-color-emoji
  ];

  system.stateVersion = "26.11";
}
