{ lib, ... }:
let
  locked = bind: { _props.allow-when-locked = true; } // bind;

  tui = command: {
    spawn = [
      "foot"
      "--app-id"
      (builtins.head command)
    ]
    ++ command;
  };

  workspaceBinds = lib.mergeAttrsList (
    map (n: {
      "Mod+${toString n}".focus-workspace = n;
      "Mod+Ctrl+${toString n}".move-column-to-workspace = n;
    }) (lib.range 1 9)
  );
in
{
  wayland.windowManager.niri.settings = {
    recent-windows.binds = {
      "Mod+Tab".next-window = { };
      "Mod+Shift+Tab".previous-window = { };
    };

    binds = workspaceBinds // {
      "XF86AudioRaiseVolume" = locked {
        spawn-sh = "swayosd-client --output-volume +10 --max-volume 100";
      };
      "XF86AudioLowerVolume" = locked { spawn-sh = "swayosd-client --output-volume -10"; };
      "XF86AudioMute" = locked { spawn-sh = "swayosd-client --output-volume mute-toggle"; };
      "XF86AudioMicMute" = locked { spawn-sh = "swayosd-client --input-volume mute-toggle"; };
      "XF86AudioPlay" = locked { spawn-sh = "playerctl play-pause"; };
      "XF86AudioStop" = locked { spawn-sh = "playerctl stop"; };
      "XF86AudioPrev" = locked { spawn-sh = "playerctl previous"; };
      "XF86AudioNext" = locked { spawn-sh = "playerctl next"; };
      "XF86MonBrightnessUp" = locked { spawn-sh = "swayosd-client --brightness +10"; };
      "XF86MonBrightnessDown" = locked { spawn-sh = "swayosd-client --brightness -10"; };

      "Mod+O" = {
        _props.repeat = false;
        _props.allow-inhibiting = false;
        toggle-overview = { };
      };
      "Mod+Q".close-window = { };

      "Mod+H".focus-column-left = { };
      "Mod+J".focus-window-or-workspace-down = { };
      "Mod+K".focus-window-or-workspace-up = { };
      "Mod+L".focus-column-right = { };

      "Mod+Shift+H".move-column-left = { };
      "Mod+Shift+J".move-window-down-or-to-workspace-down = { };
      "Mod+Shift+K".move-window-up-or-to-workspace-up = { };
      "Mod+Shift+L".move-column-right = { };

      "Mod+Ctrl+H".focus-monitor-left = { };
      "Mod+Ctrl+J".focus-monitor-down = { };
      "Mod+Ctrl+K".focus-monitor-up = { };
      "Mod+Ctrl+L".focus-monitor-right = { };

      "Mod+Shift+Ctrl+H".move-column-to-monitor-left = { };
      "Mod+Shift+Ctrl+J".move-column-to-monitor-down = { };
      "Mod+Shift+Ctrl+K".move-column-to-monitor-up = { };
      "Mod+Shift+Ctrl+L".move-column-to-monitor-right = { };

      "Mod+WheelScrollDown" = {
        _props.cooldown-ms = 150;
        focus-workspace-down = { };
      };
      "Mod+WheelScrollUp" = {
        _props.cooldown-ms = 150;
        focus-workspace-up = { };
      };
      "Mod+WheelScrollRight".focus-column-right = { };
      "Mod+WheelScrollLeft".focus-column-left = { };
      "Mod+Shift+WheelScrollDown".focus-column-left = { };
      "Mod+Shift+WheelScrollUp".focus-column-right = { };

      "Mod+Comma".consume-or-expel-window-left = { };
      "Mod+Period".consume-or-expel-window-right = { };

      "Mod+F".maximize-column = { };
      "Mod+Shift+F".fullscreen-window = { };
      "Mod+Ctrl+F".maximize-window-to-edges = { };

      "Mod+Minus".set-column-width = "-10%";
      "Mod+Plus".set-column-width = "+10%";
      "Mod+Shift+Minus".set-window-height = "-10%";
      "Mod+Shift+Plus".set-window-height = "+10%";

      "Mod+V".toggle-window-floating = { };
      "Mod+Shift+V".switch-focus-between-floating-and-tiling = { };

      "Mod+C".screenshot = { };
      "Mod+Shift+C".screenshot-window = { };

      "Mod+Escape" = {
        _props.allow-inhibiting = false;
        toggle-keyboard-shortcuts-inhibit = { };
      };

      "Mod+Shift+E".quit = { };

      "Mod+Space".spawn = "fuzzel";
      "Mod+T".spawn = "foot";
      "Mod+B".spawn = "chromium-privat";
      "Mod+Ctrl+B" = tui [ "bluetui" ];
      "Mod+Ctrl+A" = tui [
        "wiremix"
        "-v"
        "playback"
      ];
      "Mod+Ctrl+T" = tui [ "btop" ];
      "Mod+Ctrl+Y".spawn-sh = "cliphist list | fuzzel --dmenu --with-nth 2 | cliphist decode | wl-copy";
    };
  };
}
